ONLINE AI চালু করার নির্দেশ (একবার setup দরকার)

1. GitHub-এ project upload করুন।
2. Render.com-এ Web Service তৈরি করে একই GitHub repository connect করুন।
3. Root Directory: backend
4. Build Command: npm install
5. Start Command: npm start
6. Environment Variables যোগ করুন:
   OPENAI_API_KEY = আপনার OpenAI API key
   OPENAI_MODEL = আপনার account-এ উপলব্ধ model ID
7. Deploy হলে Render HTTPS URL দেবে।

Android app-এর app/build.gradle-এ AI_BACKEND_URL field যোগ/সেট করতে হবে এবং URL বসিয়ে আবার APK build করতে হবে। API key কখনও Android app-এ রাখবেন না। API ব্যবহারে খরচ হতে পারে।
