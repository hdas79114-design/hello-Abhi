import express from "express";
import OpenAI from "openai";
const app = express();
app.use(express.json({limit:"32kb"}));
const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
app.get("/", (_req,res)=>res.json({status:"ok",app:"Abir AI"}));
app.post("/chat", async (req,res)=>{
  try {
    if (!client) return res.status(503).json({error:"OPENAI_API_KEY not configured"});
    const message=String(req.body?.message||"").trim();
    if (!message) return res.status(400).json({error:"message is required"});
    const r=await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      instructions:"তুমি Abir AI। সহজ, পরিষ্কার বাংলায় উত্তর দাও; ব্যবহারকারী অন্য ভাষায় বললে সেই ভাষায় উত্তর দাও।",
      input:message
    });
    res.json({reply:r.output_text || "দুঃখিত, উত্তর তৈরি করা যায়নি।"});
  } catch(e) { console.error(e?.message||e); res.status(500).json({error:"AI request failed"}); }
});
app.listen(process.env.PORT||3000,()=>console.log("Abir AI backend started"));
