ABIR AI — প্রজেক্ট ফাইল

এই ZIP-এ Android source code এবং GitHub Actions APK build workflow আছে।
আপনার ফোনে কাজ:
1) ZIP download করে Extract করুন।
2) GitHub-এ আপনার AbirAI repository খুলুন।
3) Extract করা ফাইলগুলো repository-তে upload করুন (ZIP ফাইলটি একা নয়)।
4) Actions → Build Abir AI APK → Run workflow / সর্বশেষ run খুলুন।
5) Artifacts থেকে abir-ai-debug-apk download করুন, ZIP খুলে app-debug.apk ইনস্টল করুন।

গুরুত্বপূর্ণ: এই workflow APK build করে; এটি নিজে থেকে আপনার GitHub-এ upload করতে পারে না।
Online AI চালাতে আলাদা backend এবং API key সেটআপ দরকার। API key APK-তে রাখবেন না।
